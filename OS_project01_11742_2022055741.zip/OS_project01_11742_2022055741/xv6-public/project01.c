#include "types.h"
#include "stat.h"
#include "user.h"

int
main(int argc, char *argv[]){
char *stdInfo = "My student id is 2022055741";

//int ret_std = myfunction(stdInfo);
int p_id = getpid();
int gp_id = getgpid();

printf(1,"%s\n ", stdInfo);
printf(1,"My pid is %d\n ",p_id);
printf(1, "My gpid is %d\n ", gp_id);
exit();
};
